"""Folder scanner: reconciles the PDF folder (source of truth for files)
with the SQLite DB (source of truth for metadata).

Per file:
  1. Fast path: a row with the same path, size and mtime -> unchanged, no rehash.
  2. Otherwise compute SHA-256.
     - Hash already in DB  -> the file moved/was renamed: update path only.
     - Hash unknown        -> new book: insert with a best-effort title guess.
Rows whose hash was not confirmed in this pass are flagged missing=1
(metadata is never deleted).
"""

import hashlib
import os
import shutil
import subprocess

DATA_DIR_NAME = ".booklib"
CHUNK = 1024 * 1024


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(CHUNK):
            h.update(chunk)
    return h.hexdigest()


def _mdls_guess(path):
    """Best-effort title/author from Spotlight metadata (macOS only).
    Returns (title, author); either may be ''. Silently degrades elsewhere."""
    if shutil.which("mdls") is None:
        return "", ""
    try:
        out = subprocess.run(
            ["mdls", "-name", "kMDItemTitle", "-name", "kMDItemAuthors", path],
            capture_output=True, text=True, timeout=10,
        ).stdout
    except (subprocess.SubprocessError, OSError):
        return "", ""
    title, author = "", ""
    for line in out.splitlines():
        if "=" not in line:
            continue
        key, _, val = line.partition("=")
        val = val.strip()
        if val in ("(null)", ""):
            continue
        if "kMDItemTitle" in key:
            title = val.strip('"')
        elif "kMDItemAuthors" in key:
            author = val.strip("() \n").strip('"')
    return title, author


def guess_metadata(path):
    title, author = _mdls_guess(path)
    # Spotlight sometimes reports the bare filename (extension included) as
    # kMDItemTitle when the PDF has no embedded title; treat that as "no
    # metadata" so the title falls back to the extension-less stem.
    if not title or title == os.path.basename(path):
        title = os.path.splitext(os.path.basename(path))[0]
    return title, author


def iter_pdfs(root):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [
            d for d in dirnames if not d.startswith(".") and d != DATA_DIR_NAME
        ]
        for name in filenames:
            if name.startswith("."):
                continue
            if name.lower().endswith(".pdf"):
                yield os.path.join(dirpath, name)


def scan(conn, root):
    summary = {"added": 0, "moved": 0, "rehashed": 0, "unchanged": 0,
               "missing": 0, "recovered": 0, "duplicates": []}
    confirmed = set()

    for path in iter_pdfs(root):
        try:
            st = os.stat(path)
        except OSError:
            continue
        row = conn.execute(
            "SELECT hash, size, mtime, missing FROM books WHERE path = ?", (path,)
        ).fetchone()
        if row and row["size"] == st.st_size and row["mtime"] == st.st_mtime:
            if row["missing"]:
                conn.execute("UPDATE books SET missing = 0 WHERE hash = ?", (row["hash"],))
                summary["recovered"] += 1
            summary["unchanged"] += 1
            confirmed.add(row["hash"])
            continue

        digest = sha256_of(path)
        if digest in confirmed:
            summary["duplicates"].append(path)
            continue
        known = conn.execute(
            "SELECT path, missing FROM books WHERE hash = ?", (digest,)
        ).fetchone()
        if known:
            if known["missing"]:
                summary["recovered"] += 1
            if known["path"] != path:
                summary["moved"] += 1
            else:
                summary["rehashed"] += 1
            conn.execute(
                "UPDATE books SET path = ?, size = ?, mtime = ?, missing = 0 "
                "WHERE hash = ?",
                (path, st.st_size, st.st_mtime, digest),
            )
        else:
            title, author = guess_metadata(path)
            conn.execute(
                "INSERT INTO books(hash, path, title, author, size, mtime) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (digest, path, title, author, st.st_size, st.st_mtime),
            )
            summary["added"] += 1
        confirmed.add(digest)

    cur = conn.execute(
        "SELECT hash FROM books WHERE missing = 0"
    )
    for row in cur.fetchall():
        if row["hash"] not in confirmed:
            conn.execute("UPDATE books SET missing = 1 WHERE hash = ?", (row["hash"],))
            summary["missing"] += 1
    conn.commit()
    return summary
