"""booklib server — standard library only, no pip install required.

Usage:
    python3 app.py /path/to/your/pdf/folder [--port 8323]

Serves the UI at http://localhost:<port>/ and stores all app data in
<library>/.booklib/ (delete that one directory to fully uninstall).
Binds to 127.0.0.1 only: this is a single-user local app.
"""

import argparse
import json
import os
import re
import subprocess
import sys
import threading
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import db
import scanner
import thumbs

HASH_RE = re.compile(r"^[0-9a-f]{64}$")
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

PLACEHOLDER_SVG = (
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 240 340">'
    '<rect width="240" height="340" fill="#e8e6df"/>'
    '<rect x="0" y="0" width="14" height="340" fill="#d5d2c8"/>'
    '<text x="127" y="175" font-size="15" fill="#8b887e" text-anchor="middle" '
    'font-family="Hiragino Mincho ProN, serif">表紙なし</text></svg>'
).encode("utf-8")


class State:
    def __init__(self, library, data_dir):
        self.library = library
        self.thumbs_dir = os.path.join(data_dir, "thumbs")
        self.conn = db.connect(os.path.join(data_dir, "library.db"))
        self.lock = threading.Lock()  # sqlite conn shared across request threads
        # --auto-quit bookkeeping: open-tab refcount + last liveness signal.
        # monotonic() pauses during system sleep on macOS, so a sleeping Mac
        # does not look like a vanished browser.
        self.tabs = 0
        self.had_tab = False
        self.last_seen = time.monotonic()


STATE = None

# --auto-quit: タブ0が続いたら終了(リロード時のbye→helloを猶予で吸収)。
# 通知の完全な途絶はブラウザ強制終了等の保険。非表示タブはタイマーが
# 約1分に間引かれるため、タイムアウトはそれより十分長くとる。
QUIT_POLL_SEC = 2
QUIT_BYE_GRACE_SEC = 10
QUIT_PING_TIMEOUT_SEC = 120


def _watchdog(server):
    while True:
        time.sleep(QUIT_POLL_SEC)
        with STATE.lock:
            idle = time.monotonic() - STATE.last_seen
            closed = STATE.had_tab and STATE.tabs == 0
        if (closed and idle > QUIT_BYE_GRACE_SEC) or idle > QUIT_PING_TIMEOUT_SEC:
            print("ブラウザが閉じられたため自動終了します")
            server.shutdown()
            return


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):  # quieter console
        pass

    # ---- helpers -------------------------------------------------------
    def _send(self, status, body, ctype="application/json; charset=utf-8",
              extra=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, status=200):
        self._send(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _error(self, status, message):
        self._json({"error": message}, status)

    def _read_body(self):
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > 1_000_000:
            return None
        try:
            return json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            return None

    def _book_or_404(self, book_hash):
        if not HASH_RE.match(book_hash):
            self._error(400, "不正なIDです"); return None
        with STATE.lock:
            book = db.get_book(STATE.conn, book_hash)
        if book is None:
            self._error(404, "その本は登録されていません"); return None
        return book

    # ---- GET -----------------------------------------------------------
    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        parts = [p for p in url.path.split("/") if p]

        if url.path == "/":
            with open(os.path.join(STATIC_DIR, "index.html"), "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        elif url.path == "/api/books":
            q = urllib.parse.parse_qs(url.query)
            with STATE.lock:
                books = db.search_books(
                    STATE.conn,
                    query=q.get("q", [""])[0],
                    tags=q.get("tags", []),
                    sort=q.get("sort", ["added"])[0],
                )
            self._json({"books": books})
        elif url.path == "/api/tags":
            with STATE.lock:
                tags = db.list_tags(STATE.conn)
            self._json({"tags": tags})
        elif len(parts) == 2 and parts[0] == "thumb":
            self._serve_thumb(parts[1])
        elif len(parts) == 2 and parts[0] == "file":
            self._serve_pdf(parts[1])
        else:
            self._error(404, "not found")

    def _serve_thumb(self, book_hash):
        book = self._book_or_404(book_hash)
        if book is None:
            return
        png = thumbs.ensure_thumb(book_hash, book["path"], STATE.thumbs_dir)
        if png:
            with open(png, "rb") as f:
                self._send(200, f.read(), "image/png",
                           {"Cache-Control": "max-age=86400"})
        else:
            self._send(200, PLACEHOLDER_SVG, "image/svg+xml",
                       {"Cache-Control": "max-age=3600"})

    def _serve_pdf(self, book_hash):
        book = self._book_or_404(book_hash)
        if book is None:
            return
        if not os.path.exists(book["path"]):
            self._error(404, "ファイルが見つかりません(所在不明)")
            return
        with open(book["path"], "rb") as f:
            data = f.read()
        self._send(200, data, "application/pdf",
                   {"Content-Disposition": "inline"})

    # ---- POST ----------------------------------------------------------
    def do_POST(self):
        parts = [p for p in self.path.split("/") if p]

        if self.path == "/api/scan":
            with STATE.lock:
                summary = scanner.scan(STATE.conn, STATE.library)
            self._json(summary)
        elif self.path in ("/api/hello", "/api/ping", "/api/bye"):
            # Liveness signals from the UI (used by --auto-quit).
            with STATE.lock:
                if self.path == "/api/hello":
                    STATE.tabs += 1
                    STATE.had_tab = True
                elif self.path == "/api/bye":
                    STATE.tabs = max(0, STATE.tabs - 1)
                STATE.last_seen = time.monotonic()
            self._json({})
        elif len(parts) == 3 and parts[:2] == ["api", "books"]:
            self._update_book(parts[2])
        elif len(parts) == 3 and parts[:2] == ["api", "open"]:
            self._open_book(parts[2])
        else:
            self._error(404, "not found")

    # ---- DELETE --------------------------------------------------------
    def do_DELETE(self):
        parts = [p for p in self.path.split("/") if p]
        if len(parts) == 3 and parts[:2] == ["api", "books"]:
            book = self._book_or_404(parts[2])
            if book is None:
                return
            # 実在するファイルの記録は消させない(不変条件の例外は所在不明のみ)
            if not book["missing"]:
                self._error(400, "所在不明の本のみ削除できます")
                return
            with STATE.lock:
                db.delete_book(STATE.conn, book["hash"])
            try:  # 表紙キャッシュも掃除(PDF本体はそもそも存在しない)
                os.remove(os.path.join(STATE.thumbs_dir, book["hash"] + ".png"))
            except OSError:
                pass
            self._json({})
        else:
            self._error(404, "not found")

    def _update_book(self, book_hash):
        book = self._book_or_404(book_hash)
        if book is None:
            return
        body = self._read_body()
        if body is None:
            self._error(400, "JSONボディが必要です")
            return
        tags = body.get("tags")
        if tags is not None and not (
            isinstance(tags, list) and all(isinstance(t, str) for t in tags)
        ):
            self._error(400, "tagsは文字列の配列で指定してください")
            return
        inherit = body.get("inherit_from")
        if inherit is not None and not (
            isinstance(inherit, str) and HASH_RE.match(inherit)
        ):
            self._error(400, "inherit_fromが不正です")
            return
        with STATE.lock:
            db.update_book(
                STATE.conn, book_hash,
                title=body.get("title"), author=body.get("author"), tags=tags,
                inherit_from=inherit,
            )
            self._json({"book": db.get_book(STATE.conn, book_hash)})

    def _open_book(self, book_hash):
        book = self._book_or_404(book_hash)
        if book is None:
            return
        if not os.path.exists(book["path"]):
            self._error(404, "ファイルが見つかりません(所在不明)")
            return
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        try:
            subprocess.Popen([opener, book["path"]])
        except OSError as e:
            self._error(500, f"開けませんでした: {e}")
            return
        self._json({"ok": True})


def main():
    global STATE
    ap = argparse.ArgumentParser(description="booklib — 蔵書PDF管理")
    ap.add_argument(
        "library", nargs="?", default=None,
        help="PDFを保管しているフォルダのパス(省略時: app.pyと同じ階層のlibrary/)",
    )
    ap.add_argument("--port", type=int, default=8323)
    ap.add_argument(
        "--auto-quit", action="store_true",
        help="ブラウザのタブがすべて閉じられたら自動終了する(書庫.appランチャー用)",
    )
    args = ap.parse_args()

    if args.library is None:
        library = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "library"
        )
        os.makedirs(library, exist_ok=True)
    else:
        library = os.path.abspath(os.path.expanduser(args.library))
        if not os.path.isdir(library):
            sys.exit(f"フォルダが見つかりません: {library}")
    data_dir = os.path.join(library, scanner.DATA_DIR_NAME)
    os.makedirs(data_dir, exist_ok=True)
    STATE = State(library, data_dir)

    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    if args.auto_quit:
        threading.Thread(target=_watchdog, args=(server,), daemon=True).start()
    print(f"書庫: {library}")
    print(f"http://localhost:{args.port}/ で起動しました (Ctrl+C で終了)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
